from flask import Flask, request, jsonify
import boto3
from botocore.exceptions import NoCredentialsError

application = Flask(__name__)

# Nome do bucket e região
BUCKET_NAME = 'credit-risk-datalake'
REGION_NAME = 'us-east-1'

# Configuração do cliente S3
s3_client = boto3.client('s3', region_name=REGION_NAME)

@application.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'message': 'Nenhum arquivo encontrado na requisição'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'message': 'Arquivo não selecionado'}), 400

    folder_name = "raw"  # Substitua pelo nome da sua pasta
    file_key = f"{folder_name}/{file.filename}"

    try:
        print(f"Enviando o arquivo {file.filename} para {file_key} no bucket {BUCKET_NAME}.")
        s3_client.upload_fileobj(file, BUCKET_NAME, file_key)
        print(f"Arquivo enviado com sucesso para {file_key} no bucket {BUCKET_NAME}.")
        return jsonify({'message': f'Arquivo enviado para a pasta {folder_name} com sucesso!'}), 200
    except NoCredentialsError:
        print("Erro: Credenciais AWS não configuradas ou inválidas.")
        return jsonify({'message': 'Credenciais AWS inválidas ou ausentes'}), 500
    except Exception as e:
        print(f"Erro ao enviar o arquivo: {e}")
        return jsonify({'message': 'Erro ao enviar o arquivo', 'error': str(e)}), 500

if __name__ == '__main__':
    application.run(debug=True)
