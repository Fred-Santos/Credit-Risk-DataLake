import boto3
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import sys

# Configurações do S3
bucket_name = 'credit-risk-datalake'  # Nome do seu bucket
validated_path = 'Bronze/validated/'  # Caminho para onde mover arquivos validados
rejected_path = 'Bronze/rejected/'    # Caminho para onde mover arquivos rejeitados
report_path = 'Bronze/relatorio/'     # Caminho para onde salvar o relatório

# Configurações do e-mail
sender_email = "{Insira o Remetente}"
sender_password = "xxxx xxxx xxxx xxxx" {Chave de segurança do email do remetente}
receiver_email = "{Insira o Destinatário}"

# Criando o cliente S3
s3 = boto3.client('s3')

# Configuração do Spark
spark = SparkSession.builder \
    .appName("Validate Credit Risk Data") \
    .getOrCreate()

# Função para mover o arquivo para a pasta "rejected" no S3
def move_to_rejected(file_key):
    try:
        rejected_file_key = rejected_path + file_key.split('/')[-1]
        s3.copy_object(
            Bucket=bucket_name,
            CopySource={'Bucket': bucket_name, 'Key': file_key},
            Key=rejected_file_key
        )
        s3.delete_object(Bucket=bucket_name, Key=file_key)
        logging.info(f"Arquivo movido para rejected: {rejected_file_key}")
    except Exception as e:
        logging.error(f"Erro ao mover arquivo para rejected: {str(e)}")

# Função para mover o arquivo para a pasta "validated" no S3
def move_to_validated(file_key):
    try:
        validated_file_key = validated_path + file_key.split('/')[-1]
        s3.copy_object(
            Bucket=bucket_name,
            CopySource={'Bucket': bucket_name, 'Key': file_key},
            Key=validated_file_key
        )
        s3.delete_object(Bucket=bucket_name, Key=file_key)
        logging.info(f"Arquivo movido para validated: {validated_file_key}")
    except Exception as e:
        logging.error(f"Erro ao mover arquivo para validated: {str(e)}")

# Função para carregar o dataset
def load_data(file_key):
    try:
        df = spark.read.csv(f's3://{bucket_name}/{file_key}', header=True, inferSchema=True)
        return df
    except Exception as e:
        logging.error(f"Erro ao carregar o dataset: {str(e)}")
        move_to_rejected(file_key)
        return None

# Função para salvar o relatório no S3
def save_report_txt(report, file_key):
    try:
        # Criar o conteúdo do relatório
        null_details = "\n".join(
            [f"{col}: {perc:.2f}%" for col, perc in report["null_percentage_by_column"].items()]
        )
        
        report_content = (
            f"Arquivo válido: {'Sim' if report['is_valid'] else 'Não'}\n"
            f"Percentual de nulos por coluna:\n{null_details}\n\n"
            f"Nulos no total: {report['null_percentage']:.2f}%\n"
            f"Colunas diferentes das esperadas: "
            f"{'Não há' if not report['missing_columns'] else ', '.join(report['missing_columns'])}\n"
        )
        
        # Define o nome do arquivo e salva localmente
        report_file_name = f"{report_path}relatorio_{file_key.split('/')[-1].split('.')[0]}_{datetime.now().strftime('%Y%m%d')}.txt"
        local_file_path = f"/tmp/{report_file_name.split('/')[-1]}"
        
        with open(local_file_path, 'w') as file:
            file.write(report_content)
        
        # Envia o arquivo para o S3
        s3.upload_file(local_file_path, bucket_name, report_file_name)
        logging.info(f"Relatório salvo em: {report_file_name}")
        
        # Retorna o caminho do arquivo local para envio de e-mail
        return local_file_path
    except Exception as e:
        logging.error(f"Erro ao salvar o relatório: {str(e)}")
        return None

# Função para validar o dataset
def validate_data(df, file_key):
    try:
        if df is None:
            return None, "Arquivo não pôde ser carregado."
        
        required_columns = [
            'person_age', 'person_income', 'person_home_ownership', 'person_emp_length',
            'loan_intent', 'loan_grade', 'loan_amnt', 'loan_int_rate', 'loan_status',
            'loan_percent_income', 'cb_person_default_on_file', 'cb_person_cred_hist_length'
        ]
        
        report = {
            "is_valid": False,
            "null_percentage": 0,
            "missing_columns": [],
            "null_percentage_by_column": {}  # Adiciona o detalhamento por coluna
        }
        
        # Verificar colunas ausentes
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            report["missing_columns"] = missing_columns
            return report, "Colunas ausentes."
        
        # Total de linhas no dataset
        total_rows = df.count()

        # Calcular a porcentagem de valores nulos por coluna
        for column in required_columns:
            null_count = df.filter(col(column).isNull()).count()
            null_percentage = (null_count / total_rows) * 100
            report["null_percentage_by_column"][column] = null_percentage

        # Verificar se mais de 15% dos valores são nulos no total
        overall_null_count = sum(df.filter(col(c).isNull()).count() for c in required_columns)
        overall_null_percentage = (overall_null_count / (total_rows * len(required_columns))) * 100
        report["null_percentage"] = overall_null_percentage
        
        # Validar com base na regra
        if overall_null_percentage > 15:
            return report, f"Mais de 15% dos dados essenciais estão nulos ({overall_null_percentage:.2f}%)."
        
        report["is_valid"] = True
        return report, "Validação concluída com sucesso."
    except Exception as e:
        logging.error(f"Erro ao validar o dataset: {str(e)}")
        move_to_rejected(file_key)
        return None, str(e)

# Função para enviar e-mail com o relatório anexado
def send_email_with_report(report_file_path):
    try:
        # Configurando o e-mail
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = "Relatório de Validação de Dados"
        
        body = "Segue em anexo o relatório de validação dos dados."
        msg.attach(MIMEText(body, 'plain'))
        
        # Anexando o arquivo
        attachment = open(report_file_path, 'rb')
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', f"attachment; filename={report_file_path.split('/')[-1]}")
        msg.attach(part)
        
        # Enviando o e-mail
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, msg.as_string())
        server.quit()
        
        logging.info("E-mail enviado com sucesso!")
    except Exception as e:
        logging.error(f"Erro ao enviar o e-mail: {str(e)}")

# Função principal
def main(file_key):
    try:
        df = load_data(file_key)
        report, message = validate_data(df, file_key)
        
        if report:
            report_file_path = save_report_txt(report, file_key)
            if report_file_path:
                send_email_with_report(report_file_path)
            
            if report["is_valid"]:
                move_to_validated(file_key)  # Mover para a pasta validated
            else:
                move_to_rejected(file_key)   # Mover para a pasta rejected
            logging.info(f"Processamento concluído: {message}")
        else:
            logging.error("Erro na validação: Relatório não gerado.")
    except Exception as e:
        logging.error(f"Erro no processo completo: {str(e)}")
        move_to_rejected(file_key)

# Configurações de logging
logging.basicConfig(level=logging.INFO)

# Chamada principal
if __name__ == "__main__":
    import sys
    from awsglue.utils import getResolvedOptions

    # Lê os parâmetros passados para o Glue Job
    args = getResolvedOptions(sys.argv, ['file_key'])

    # Obtém o valor do parâmetro file_key
    file_key = args['file_key']

    # Chama a função principal com o arquivo indicado
    main(file_key)