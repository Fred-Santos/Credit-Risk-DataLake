import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import when, col, count, sum as _sum, round, avg
import boto3
import traceback

# Inicializar SparkSession com suporte ao Glue
spark = SparkSession.builder.appName("Credit Risk Gold Layer").getOrCreate()

# Cliente S3 para registrar logs
s3_client = boto3.client('s3')

# Função para gravar o erro no S3
def log_error_to_s3(error_message, bucket_name, gold_folder_name):
    error_file_key = f"Gold/Individual/error_log.txt"
    s3_client.put_object(
        Bucket=bucket_name,
        Key=error_file_key,
        Body=error_message
    )

try:
    # Obter argumentos passados pela Lambda
    args = sys.argv
    gold_folder_name = args[args.index('--gold_folder_name') + 1]
    gold_triggered_file = args[args.index('--gold_triggered_file') + 1]
    # Caminhos dinâmicos no S3
    silver_path = f"s3://credit-risk-datalake/Silver/{gold_folder_name}/*"
    gold_path_base = f"s3://credit-risk-datalake/Gold/Individual/{gold_folder_name}/"

    # Carregar o arquivo Parquet da camada Silver
    df = spark.read.parquet(silver_path)

    # 1. Tabela resumo_risco_credito
    df.createOrReplaceTempView("tabela_emprestimos_persistente")
    query_resumo_risco_credito = """
    SELECT
        `classificação_do_empréstimo`,
        COUNT(*) AS `quantidade_total_empréstimos`,
        SUM(`quantidade_do_empréstimo`) AS `valor_total_empréstimos`,
        ROUND(AVG(`quantidade_do_empréstimo`), 2) AS `valor_médio_empréstimos`,
        ROUND(100.0 * SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS porcentual_inadimplentes
    FROM tabela_emprestimos_persistente
    GROUP BY `classificação_do_empréstimo`
    ORDER BY `classificação_do_empréstimo`;
    """
    resumo_risco_credito = spark.sql(query_resumo_risco_credito)
    resumo_risco_credito.write.mode("overwrite").parquet(f"{gold_path_base}resumo_risco_credito")

    # 2. Tabela tempo_de_emprego_x_concessao_credito
    df = df.withColumn(
        "faixa_de_tempo_de_emprego",
        when(col("tempo_de_emprego") < 1, "0-1")
        .when((col("tempo_de_emprego") >= 1) & (col("tempo_de_emprego") < 3), "1-3")
        .when((col("tempo_de_emprego") >= 3) & (col("tempo_de_emprego") < 5), "3-5")
        .otherwise("5 ou maior")
    )
    df.createOrReplaceTempView("tabela_emprestimos_com_tempo_emprego")
    query_tempo_emprego = """
    SELECT
        faixa_de_tempo_de_emprego AS tempo_de_emprego,
        COUNT(*) AS `quantidade_total_empréstimos`,
        SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) AS quantidade_inadimplente,
        ROUND(100.0 * SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS `percentual_inadimplência`
    FROM tabela_emprestimos_com_tempo_emprego
    GROUP BY faixa_de_tempo_de_emprego
    ORDER BY faixa_de_tempo_de_emprego;
    """
    tempo_de_emprego_x_concessao_credito = spark.sql(query_tempo_emprego)
    tempo_de_emprego_x_concessao_credito.write.mode("overwrite").parquet(f"{gold_path_base}tempo_de_emprego_x_concessao_credito")

    # 3. Tabela estudo_publico
    query_estudo_publico = """
    SELECT
        `intenção_do_empréstimo`,
        ROUND(AVG(idade_da_pessoa), 2) AS `idade_média`,
        ROUND(AVG(renda_da_pessoa), 2) AS `renda_média`,
        ROUND(AVG(tempo_de_emprego), 2) AS `tempo_médio_de_emprego`,
        COUNT(*) AS `quantidade_total_empréstimos`
    FROM tabela_emprestimos_persistente
    GROUP BY `intenção_do_empréstimo`
    ORDER BY `intenção_do_empréstimo`;
    """
    estudo_publico = spark.sql(query_estudo_publico)
    estudo_publico.write.mode("overwrite").parquet(f"{gold_path_base}estudo_publico")

    # 4. Tabela inadimplencia_por_faixa_de_renda
    df = df.withColumn(
        "faixa_de_renda",
        when(col("renda_da_pessoa") < 18000, "R$0 a R$17999,99")
        .when((col("renda_da_pessoa") >= 18000) & (col("renda_da_pessoa") < 36000), "R$18000,00 a R$35999,99")
        .when((col("renda_da_pessoa") >= 36000) & (col("renda_da_pessoa") < 60000), "R$36000,00 a R$59999,99")
        .when((col("renda_da_pessoa") >= 60000) & (col("renda_da_pessoa") < 120000), "R$60000,00 a R$119999,99")
        .otherwise("R$120000,00 ou maior")
    )
    df.createOrReplaceTempView("tabela_emprestimos_com_faixa_de_renda")
    query_faixa_renda = """
    SELECT
        faixa_de_renda,
        COUNT(*) AS `quantidade_total_empréstimos`,
        SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) AS quantidade_inadimplente,
        ROUND(100.0 * SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS `percentual_inadimplência`
    FROM tabela_emprestimos_com_faixa_de_renda
    GROUP BY faixa_de_renda
    ORDER BY faixa_de_renda;
    """
    inadimplencia_por_faixa_de_renda = spark.sql(query_faixa_renda)
    inadimplencia_por_faixa_de_renda.write.mode("overwrite").parquet(f"{gold_path_base}inadimplencia_por_faixa_de_renda")

    # 5. Tabela inadimplencia_por_tempo_credito
    df = df.withColumn(
        "faixa_tempo_credito",
        when(col("tempo_de_crédito_da_pessoa") < 1, "0-1")
        .when((col("tempo_de_crédito_da_pessoa") >= 1) & (col("tempo_de_crédito_da_pessoa") < 3), "1-3")
        .when((col("tempo_de_crédito_da_pessoa") >= 3) & (col("tempo_de_crédito_da_pessoa") < 5), "3-5")
        .otherwise("5 ou maior")
    )
    df.createOrReplaceTempView("tabela_emprestimos_com_tempo_credito")
    query_tempo_credito = """
    SELECT
        faixa_tempo_credito,
        COUNT(*) AS `quantidade_total_empréstimos`,
        SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) AS quantidade_inadimplente,
        ROUND(100.0 * SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS `percentual_inadimplência`
    FROM tabela_emprestimos_com_tempo_credito
    GROUP BY faixa_tempo_credito
    ORDER BY faixa_tempo_credito;
    """
    inadimplencia_por_tempo_credito = spark.sql(query_tempo_credito)
    inadimplencia_por_tempo_credito.write.mode("overwrite").parquet(f"{gold_path_base}inadimplencia_por_tempo_credito")

    # 6. Tabela distribuicao_de_emprestimos_por_propriedade
    df.createOrReplaceTempView("tabela_emprestimos_com_propriedade")
    query_propriedade = """
    SELECT
        propriedade_da_casa_da_pessoa,
        COUNT(*) AS `quantidade_total_empréstimos`,
        SUM(`quantidade_do_empréstimo`) AS `valor_total_empréstimos`,
        ROUND(100.0 * SUM(CASE WHEN `status_do_empréstimo` = 0 THEN 1 ELSE 0 END) / COUNT(*), 2) AS `percentual_inadimplência`
    FROM tabela_emprestimos_com_propriedade
    GROUP BY propriedade_da_casa_da_pessoa
    ORDER BY propriedade_da_casa_da_pessoa;
    """
    distribuicao_de_emprestimos_por_propriedade = spark.sql(query_propriedade)
    distribuicao_de_emprestimos_por_propriedade.write.mode("overwrite").parquet(f"{gold_path_base}distribuicao_de_emprestimos_por_propriedade")

    # Finalização
    print("Processamento da camada Gold concluído com sucesso.")

except Exception as e:
    error_message = f"Erro ocorrido: {str(e)}\n{traceback.format_exc()}"
    log_error_to_s3(error_message, 'credit-risk-datalake', 'Gold/Individual/error_log.txt')
    print("Erro registrado no S3.")

