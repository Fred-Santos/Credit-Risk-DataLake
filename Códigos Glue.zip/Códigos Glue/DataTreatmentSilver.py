import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, lit, current_date, avg

# Inicializa a SparkSession
spark = SparkSession.builder.appName("Camada Prata - Tratamento de Dados").getOrCreate()

# Recebe os argumentos passados pela Lambda
args = sys.argv
silver_folder_name = args[args.index("--silver_folder_name") + 1]

# Configurações
input_path = "s3://credit-risk-datalake/Bronze/validated/"
output_path = f"s3://credit-risk-datalake/Silver/{silver_folder_name}/"

# Dicionário de tradução
MANUAL_TRANSLATION = {
    'person_age': 'idade_da_pessoa',
    'person_income': 'renda_da_pessoa',
    'person_home_ownership': 'propriedade_da_casa_da_pessoa',
    'person_emp_length': 'tempo_de_emprego',
    'loan_intent': 'intenção_do_empréstimo',
    'loan_grade': 'classificação_do_empréstimo',
    'loan_amnt': 'quantidade_do_empréstimo',
    'loan_int_rate': 'taxa_de_juros_do_empréstimo',
    'loan_status': 'status_do_empréstimo',
    'loan_percent_income': 'percentual_de_renda_do_empréstimo',
    'cb_person_default_on_file': 'historico_de_inadimplencia',
    'cb_person_cred_hist_length': 'tempo_de_crédito_da_pessoa',
    'extraction_date': 'data_de_extracao'
}

# Dicionário de tradução para os valores das colunas
VALUE_TRANSLATION = {
    'propriedade_da_casa_da_pessoa': {
        'RENT': 'Alugar',
        'OWN': 'Possuir',
        'MORTGAGE': 'Hipoteca',
        'OTHER': 'Outro'
    },
    'intenção_do_empréstimo': {
        'DEBTCONSOLIDATION': 'Consolidação de Dívidas',
        'EDUCATION': 'Educação',
        'HOMEIMPROVEMENT': 'Reforma Residencial',
        'MEDICAL': 'Médico',
        'PERSONAL': 'Pessoal',
        'VENTURE': 'Empreendimento'
    }
}

# Lê os dados da camada Bronze
df = spark.read.csv(input_path, header=True, inferSchema=True)

# Tratamentos:
# 1. Renomear colunas
for original, new_name in MANUAL_TRANSLATION.items():
    if original in df.columns:
        df = df.withColumnRenamed(original, new_name)

# 2. Remover duplicatas
df = df.dropDuplicates()

# 3. Preencher valores nulos
# Calcula a média para substituir valores nulos na idade
if 'idade_da_pessoa' in df.columns:
    average_age = df.select(avg(col('idade_da_pessoa'))).collect()[0][0]
    df = df.withColumn('idade_da_pessoa', when(col('idade_da_pessoa').isNull(), average_age).otherwise(col('idade_da_pessoa')))

# Outros preenchimentos de valores nulos
columns_to_fill = {
    'renda_da_pessoa': 0,
    'tempo_de_emprego': 0,
    'classificação_do_empréstimo': 'N/A',
    'status_do_empréstimo': 'N/A'
}
for column, default_value in columns_to_fill.items():
    if column in df.columns:
        df = df.fillna({column: default_value})

# 4. Traduzir valores nas colunas especificadas
for column, translations in VALUE_TRANSLATION.items():
    if column in df.columns:
        for original_value, translated_value in translations.items():
            df = df.withColumn(column, when(col(column) == original_value, translated_value).otherwise(col(column)))

# 5. Adicionar coluna de data de extração
df = df.withColumn("data_de_extracao", lit(current_date()))

# Salvar os dados no formato Parquet
df.write.mode("overwrite").parquet(output_path)

print(f"Dados tratados e salvos com sucesso em: {output_path}")
