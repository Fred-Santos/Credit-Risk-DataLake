Documentação do Código: Upload de Arquivos para S3 com Flask
Introdução
Este script implementa uma aplicação Flask que permite realizar o upload de arquivos para um bucket S3 na AWS. Ele inclui validações básicas de entrada e trata erros relacionados a credenciais ou falhas na operação de upload. O endpoint é projetado para receber arquivos enviados via requisições HTTP POST.

Código com Comentários
from flask import Flask, request, jsonify
import boto3
from botocore.exceptions import NoCredentialsError

# Inicialização da aplicação Flask
application = Flask(__name__)

# Nome do bucket e região configurados para o S3
BUCKET_NAME = 'credit-risk-datalake'  # Substitua pelo nome do seu bucket
REGION_NAME = 'us-east-1'             # Região onde o bucket está localizado

# Criação do cliente S3 usando o boto3
s3_client = boto3.client('s3', region_name=REGION_NAME)

@application.route('/upload', methods=['POST'])
def upload_file():
    """
    Endpoint para upload de arquivos para um bucket S3.

    Este endpoint aceita arquivos enviados via POST em formato multipart form-data. Os arquivos serão salvos em uma subpasta "raw" no bucket S3 especificado.

    Retornos:
        - 200: Sucesso no envio do arquivo.
        - 400: Falha na validação do arquivo (nenhum arquivo enviado ou nome de arquivo vazio).
        - 500: Erro interno no servidor (problemas com credenciais ou erro ao enviar o arquivo).
    """
    # Verifica se o arquivo foi enviado na requisição
    if 'file' not in request.files:
        return jsonify({'message': 'Nenhum arquivo encontrado na requisição'}), 400

    file = request.files['file']
    
    # Verifica se o arquivo enviado possui um nome válido
    if file.filename == '':
        return jsonify({'message': 'Arquivo não selecionado'}), 400

    # Define a pasta de destino no bucket S3
    folder_name = "raw"  # Nome da subpasta dentro do bucket
    file_key = f"{folder_name}/{file.filename}"

    try:
        print(f"Enviando o arquivo {file.filename} para {file_key} no bucket {BUCKET_NAME}.")
        
        # Realiza o upload do arquivo para o bucket S3
        s3_client.upload_fileobj(file, BUCKET_NAME, file_key)
        
        print(f"Arquivo enviado com sucesso para {file_key} no bucket {BUCKET_NAME}.")
        return jsonify({'message': f'Arquivo enviado para a pasta {folder_name} com sucesso!'}), 200
    except NoCredentialsError:
        # Trata erro de credenciais AWS ausentes ou inválidas
        print("Erro: Credenciais AWS não configuradas ou inválidas.")
        return jsonify({'message': 'Credenciais AWS inválidas ou ausentes'}), 500
    except Exception as e:
        # Trata outros erros durante o upload
        print(f"Erro ao enviar o arquivo: {e}")
        return jsonify({'message': 'Erro ao enviar o arquivo', 'error': str(e)}), 500

# Executa a aplicação Flask no modo de depuração
if __name__ == '__main__':
    application.run(debug=True)
Processo do Código
Configuração Inicial:

O bucket S3 e a região são definidos pelas variáveis BUCKET_NAME e REGION_NAME.
O cliente S3 é configurado usando o boto3, que utiliza as credenciais AWS armazenadas localmente ou fornecidas por variáveis de ambiente.
Rota de Upload (/upload):

Aceita apenas requisições POST contendo arquivos no formato multipart form-data.
Verifica se o arquivo está presente e se possui um nome válido.
Upload para o S3:

O arquivo é enviado para a pasta "raw" no bucket S3 especificado.
Em caso de sucesso, uma mensagem de confirmação é retornada com status 200.
Tratamento de Erros:

Caso as credenciais AWS estejam ausentes ou inválidas, é retornado um erro 500 com a mensagem correspondente.
Outros erros também são capturados e descritos na resposta para facilitar o debug.
Como Executar
Certifique-se de que o Python e as bibliotecas Flask, boto3 e botocore estejam instalados.
Configure suas credenciais AWS localmente usando o AWS CLI ou variáveis de ambiente.
Salve o código em um arquivo, por exemplo, app.py.
Execute a aplicação com o comando:
python app.py
Envie uma requisição POST para o endpoint /upload com um arquivo no campo file.
Dependências
Flask
boto3
botocore